# By now you know the drill. There's a section you need to read in the notes, 
# and do try to copy and past the commands to see how they work.
#
#   https://psyr.org/branches.html
#
# Remember, DON'T add any code to this script until you get to the exercises.
# Create extra scripts if you need to. A BIG part off learning to code cleanly
# is keeping everything neat and tidy.
#
# The exercises ask you to do two things, so we'll have two code sections


# ----- code expressing my own feelings about seasons -----
YOUR-CODE-HERE


# ----- code for part 2, with the loop added ----
YOUR-CODE-HERE