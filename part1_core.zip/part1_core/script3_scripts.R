# This file has the most ridiculous name. I'm sorry. 
#
# We've been opening and running scripts from the beginning, but now
# I'm going to ask you to start writing them. The reading for this
# section is here:
#
#    https://psyr.org/scripts.html
#
# Your task? Add some commands below that will solve the exercise
# in section 3.6. That is, write a script that calculates the number 
# of seconds in a year (assuming 365 days), and prints the result to
# the console

# YOUR CODE HERE!!!! :-)