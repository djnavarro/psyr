# The text to read through for this section is:
#
#   https://psyr.org/variables.html
#
# There's not much to do right now except read through that section
# type the commands as you go, and then complete the exercises in 
# part 2.6. You don't need to do anything with this script!