# The next section in the course materials discusses R packages.
# You should read through this section and it is worth typing the
# commands as you go, BUT with any luck it won't matter quite so
# much for this year's class as it has for previous years, because
# of the sneaky trick I pulled with the "script0_setup.R" file. 
# With any luck, you should have everything you need on your 
# machine already :-)
#
# The link:
#
#    https://psyr.org/packages.html