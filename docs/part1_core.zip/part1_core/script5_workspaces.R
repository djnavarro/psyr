# Oh look, another one of these scripts where you don't 
# have to type anything! The next section of the class
# introduces the idea behind the R workspace. 
#
#   https://psyr.org/workspaces.html
#
# Again, just read along, type the commands, try out the 
# exercises. 
#
# The next one will start using these scripts more though!