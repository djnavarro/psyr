# Finally, we're going to start using these scripts for
# something a little bit more than just signposting!
#
# When you get to the Exercises in 6.11, come back here
# instead. We're going to go through them in a slightly
# different way.
#
#     https://psyr.org/vectors.html
#
# You're back now? Excellent!
#
# The script below is BROKEN. The parts in ALL-CAPS are 
# where you need to make changes. You will need to go through
# it and fix all the problems using what you have learned


# create a vector of ages for four people
age <- c(SOMETHING-IS-MISSING-HERE)

# print out the age of the third person
print(SOMETHING-MISSING)

# print out the ages of the second person AND the third person
print(age[SOMETHING-MISSING])

# create a vector of genders for four people
gender <- SOMETHING

# create a logical vector that indicates whether each 
# person is an adult
adult <- SOMETHING > SOMETHING 

# print out the genders of all the adults!
OH-DEAR-EVERYTHING-IS-MISSING-THIS-TIME

# Useful tip... if you want R to run a small section of the code rather 
# than the whole script, select the part you want it to run and then
# click on the "run" button above.
#
#    Run     =  R will execute the current line or selection
#    Source  =  R will execute the entire script