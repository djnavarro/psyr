# A quick refresher to check your knowledge from part 1.
# Let's start out by creating some variables:

# Create a vector containing two numbers
num <- c(3, 7)

# Create a vector containing two pieces of text
txt <- c("hello", "world")

# Here is a function called "triple" that multiplies a number
# by three. Do you understand what each part of it does?
triple <- function(x) {
  y <- x * 3
  return(y)
}

# Create a function called "positive" that returns TRUE if
# the input x is greater than 0, and returns FALSE otherwisye
positive <- function(x) {
  y <- x > 0
  return(y)
}

# Note: this also works:
positive <- function(x) {
  if(x > 0) {
    return(TRUE)
  } else {
    return(FALSE)
  }
}




# Change this loop so that it runs for 20 iterations
for(iteration in 1:20) {
  message <- paste("hello this is iteration", iteration)
  print(message)
}

# There are two jobs here:
#   1. Insert a line of code so that R prints out "You had me at hello"
#   2. Even when you get the line right, it won't work because there is a
#      mistake somewhere in my code. Fix my mistake! :-)
greeting <- "hello"
if(greeting == "hello") {  # <- this needed to be == not =
  print("You had me at hello")
} else {
  print("Say what now?")
}


